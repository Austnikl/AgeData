"""
Austin Escobar
5/12/2022 

"""

from ast import Num
import operator
import pandas as pd
from matplotlib import pyplot as plt
import numpy as np

helpChange = {
   '18-23': '0',
   '24-29': '1',
   '30-39': '2',
   '40-49': '3',
   '50-59':'4',
   '60+': '5'
}

#return the value based on the text in excel 
def getCellInfo(df,row,name):
   text =df.loc[row][name]
  
   return ''.join(helpChange[ele] for ele in text.split())

#return the number of elements based on an num,list
def calculateAgeGroup(dataList):
   data = []
   compare = 0
   count = 0
   size = len(dataList)
   for i in range(len(dataList)):
      if compare == dataList[i]:
         count+=1
      else: 
         data.insert(compare,count)
         compare+=1
         count=0
   data.insert(compare,count)
   compare+=1
   return data

#display the piechart
def displayPieChat(data):
   ageText = ['18-23','24-29','30-39','40-49','50-59','60+']
   labels = list(ageText)
   colors = ['#52D726', '#FFEC00', '#FF7300', '#FF0000', '#007ED6', '#007ED6']


   plt.pie(data,  labels=labels, colors=colors, autopct='%1.1f%%', shadow=True, startangle=90,radius = 1.45) 

   plt.show()



df = pd.read_excel("Age Data (4) (1) (1).xlsx")


i=0
ageRange = []

#go through the age column in the excel
while i < df.shape[0]: 
    x= int(getCellInfo(df,i,"Age"))
    ageRange.append(x)
    i+=1

ageRange.sort()



#find the amount per age group

data = calculateAgeGroup(ageRange)

displayPieChat(data)